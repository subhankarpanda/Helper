﻿using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using FAF.PrintLog;

namespace SeleniumInternalHelpersSupportLibrary
{
    public class Reports
    {
        private static bool _testresult = true;
        private static string _testdescription = "TEST SUMMARY MISSING";
        private static string _teststep = "Test Step Missing";
        private static string _obj_class = "";
        //public static string TESTDIR = "";

        public static string _testname = "NA";
        private static bool _onetimeexecutionflag = true;
        private static string _testid = "";
        private static int _testsequence = 0;
        private static string _testmethodresultfolder = "";
        private static string _testagent = "";
        private static bool _IsMTMExecutions = false;
        public static string _resultsdir = "";
        private static string _deploydir = "";
        private static string _debugLog = "";
        private static string _summaryLogFile = "";
        private static string SummaryLog = "";
        private static string resultfile = "";
        private static DateTime startTime = new DateTime();
        private static DateTime endTime = new DateTime();
        private static string prevdesc = "";
        private static int TestStepNumber = 0;
        private static string prevbin = "";
        private static string _screenshotpath = "";
        private static bool _bOnetimeclearcache = true;
        private static string _buildNumber = "NA";
        private static string _testplanid = "NA";
        //public static IWebDriver driver;

        #region RUNRESULTDIR
        ///<summary>
        ///<para>Read Only. Gets Result directory of Run.</para>
        ///<para>Example: string createresulsdir = Reports.RUNRESULTSDIR;</para>
        ///</summary>
        public static string RUNRESULTDIR
        {
            get { return _resultsdir; }
        }
        #endregion

        #region DEBUGLOG
        ///<summary>
        ///<para>Read Only. Gets result file of the run.</para>
        ///<para>Example: string ResultFile = Reports.DEBUGLOG;</para>
        ///</summary>
        public static string DEBUGLOG
        {
            get { return _debugLog; }
        }
        #endregion

        #region SummaryLogFile
        ///<summary>
        ///<para>Read Only. Gets summary log file of the run.</para>
        ///<para>Example: string summaryLogFile = Reports.SummaryLogFile;</para>
        ///</summary>
        public static string SummaryLogFile
        {
            get { return _summaryLogFile; }
        }
        #endregion

        #region IsMTMExecutions
        ///<summary>
        ///<para>Read Only. Check whether test is executed via MTM or not.</para>
        ///<para>Example: bool isMTM = Reports.IsMTMExecutions;</para>
        ///</summary>
        public static bool IsMTMExecutions
        {
            get { return _IsMTMExecutions; }
        }
        #endregion

        #region DEPLOYDIR
        ///<summary>
        ///<para>Read Only. Gets Deployment Directory.</para>
        ///<para>Example: string deploydirectory = Reports.DEPLOYDIR;</para>
        ///</summary>
        public static string DEPLOYDIR
        {
            get { return _deploydir; }
        }
        #endregion

        #region _bOnetimeclearcache
        ///<summary>
        ///<para>If Set to false, Fails entire test.</para>
        ///<para>Example: Reports.TestResult = false;</para>
        ///</summary>
        public static bool bOnetimeclearcache
        {
            get { return _bOnetimeclearcache; }
            set { _bOnetimeclearcache = value; }
        }
        #endregion

        #region _agentName
        ///<summary>
        ///<para>Return Agent Name.</para>
        ///<para>Example: Reports.agentName</para>
        ///</summary>
        public static string agentName
        {
            get { return _testagent; }
        }
        #endregion

        #region _buildNumber
        ///<summary>
        ///<para>Return Build Number.</para>
        ///<para>Example: Reports.buildNumber</para>
        ///</summary>
        public static string buildNumber
        {
            get { return _buildNumber; }
        }
        #endregion

        #region _testplanid
        ///<summary>
        ///<para>Return Test Plan Id.</para>
        ///<para>Example: Reports.testplanid</para>
        ///</summary>
        public static string testplanid
        {
            get { return _testplanid; }
        }
        #endregion

        #region TestResult
        ///<summary>
        ///<para>If Set to false, Fails entire test.</para>
        ///<para>Example: Reports.TestResult = false;</para>
        ///</summary>
        public static bool TestResult
        {
            get { return _testresult; }
            set { _testresult = value; }
        }
        #endregion

        #region TestDescription
        ///<summary>
        ///<para>Test Description displayed in Reports.</para>
        ///<para>Example: Reports.TestDescription = "Verify order can be created in FAST Application";</para>
        ///</summary>
        public static string TestDescription
        {
            get { return _testdescription; }
            set { _testdescription = value; }
        }
        #endregion

        #region TestStep
        ///<summary>
        ///<para>Test Step displayed in Reports.</para>
        ///<para>Example: Reports.TestStep = "Navigate to Quick File Entry Screen.";</para>
        ///</summary>
        public static string TestStep
        {
            get { return _teststep; }
            set { _teststep = value; }
        }
        #endregion

        #region obj_class
        ///<summary>
        ///<para>Class name of Previous Control Used.</para>
        ///<para>Example: string objectclass = Reports.obj_class;</para>
        ///</summary>
        public static string obj_class
        {
            get { return _obj_class; }
            set { _obj_class = value; }
        }
        #endregion

        #region Capture Browser Image
        ///<summary>
        ///<para>Captures the Image and Saves. Ensure Set Parent is used before using this function</para>
        ///<para>Example: Reports.CaptureImage();</para>
        ///</summary>
        private static void CaptureImage()
        {
            DateTime d1 = DateTime.Now;
            string sTime = d1.ToString();
            sTime = sTime.Replace('/', '_');
            sTime = sTime.Replace(':', '_');
            sTime = sTime.Replace(' ', '_');

            _screenshotpath = "Screenshots\\" + _testname + "\\" + sTime + ".jpeg";
            string finalPath = _resultsdir + "\\" + _screenshotpath;

            using (System.Drawing.Image tmpImage = BrowserWindow.Desktop.CaptureImage())
            {
                tmpImage.Save(finalPath, ImageFormat.Jpeg);
            }
        }
        #endregion

        #region GetEnvironment
        private static string GetEnvironment(string ConfigPath, string key)
        {
            string sValue = "";
            XmlDocument xDoc = new XmlDocument();
            if (File.Exists(ConfigPath))
            {
                xDoc.Load(ConfigPath);
                sValue = xDoc.DocumentElement.SelectSingleNode(key).InnerText.Trim();
            }
            return sValue;
        }
        #endregion

        #region InitTest
        ///<summary>
        ///<para>Initializes the Test Before Run. This must be called in the TestInitialize method</para>
        ///<para>Example: Reports.InitTest(TestContext);</para>
        ///</summary>
        public static void InitTest(TestContext tContext)
        {
            TestResult = true;
            _testname = tContext.TestName;
            _deploydir = tContext.DeploymentDirectory;
            string sTime = DateTime.Now.ToString().Replace("/", "").Replace(":", "").Replace(" ", "");
            resultfile = _testname + "_" + sTime + ".xml";
            TestDescription = "TEST SUMMARY MISSING";
            TestStep = "Test Step Missing";
            TestStepNumber = 0;
            prevdesc = "";
            _testsequence = _testsequence + 1;
            _testagent = tContext.Properties["AgentName"].ToString();

            // for PrintLog Window
            PrintLog(Environment.NewLine);
            //try
            //{
            //    if (File.Exists(_deploydir + "\\PrintLog.exe") && !File.Exists(@"C:\Temp\PrintLog.exe"))
            //        File.Copy(_deploydir + "\\PrintLog.exe", @"C:\Temp\PrintLog.exe");
            //}
            //catch(Exception e)
            //{
            //    UpdateDebugLog(@"Copy PrintLog.exe to C:\Temp", "", "", "", "", "", Result(false), e.Message);
            //}

            if (_onetimeexecutionflag)
            {
                _onetimeexecutionflag = false;
                Support.GetEmbeddedFile("SeleniumInternalHelpersSupportLibrary", "AutoConfig.xml", _deploydir + "\\AutoConfig.xml");
            }

            if (tContext.Properties["__Tfs_TestConfigurationName__"] != null)
            {
                _IsMTMExecutions = true;
                _testid = _testsequence.ToString() + " / " + tContext.Properties["__Tfs_TestCaseId__"].ToString();
            }
            else
            {
                _testid = _testsequence.ToString();
            }

            if (!prevbin.Equals(tContext.FullyQualifiedTestClassName))
            {
                if (tContext.Properties["__Tfs_TestConfigurationName__"] != null)
                {
                    _IsMTMExecutions = true;
                    _buildNumber = tContext.Properties["__Tfs_BuildNumber__"].ToString();
                    _testplanid = tContext.Properties["__Tfs_TestPlanId__"].ToString();

                    Console.WriteLine("Test Run Id:" + tContext.Properties["__Tfs_TestRunId__"].ToString());
                    Console.WriteLine("TestRunDirectory:" + tContext.TestRunDirectory);
                    Console.WriteLine("DeploymentDirectory:" + tContext.DeploymentDirectory);
                    Console.WriteLine("BuildDirectory:" + tContext.Properties["__Tfs_BuildDirectory__"].ToString());
                    Console.WriteLine("TestConfigurationName:" + tContext.Properties["__Tfs_TestConfigurationName__"].ToString());

                    if (Support.TESTENVIRONMENT == "")
                    {
                        try
                        {
                            string[] files = Directory.GetFiles(_deploydir, "*.envsettings");
                            Support.TESTENVIRONMENT = GetEnvironment(files[0], "Environment");
                        }
                        catch (IndexOutOfRangeException)
                        {
                            throw new IndexOutOfRangeException("Could not find environment settings file. Make sure deployment directory is reachable.");
                        }
                    }
                }
                else
                {
                    Support.TESTENVIRONMENT = Support.ReadAppSettings("appSettings", "Environment");
                }
                Console.WriteLine("Environment: " + Support.TESTENVIRONMENT);
                prevbin = tContext.FullyQualifiedTestClassName;
                _resultsdir = @Support.ReadAppSettings("appSettings", "RESULTSDIR").TrimEnd('\\');

                _testmethodresultfolder = tContext.FullyQualifiedTestClassName + "_" + DateTime.Now.ToString("MMddyyyyHHmmss");
                if (tContext.Properties["__Tfs_TestConfigurationName__"] != null)
                    _testmethodresultfolder = _testmethodresultfolder + "_" + tContext.Properties["__Tfs_TestRunId__"].ToString();

                _resultsdir = _resultsdir + "\\" + _testmethodresultfolder;
                if (!Directory.Exists(_resultsdir))
                {
                    if (tContext.Properties["__Tfs_TestConfigurationName__"] == null)
                    {
                        _testsequence = 1;
                        _testid = _testsequence.ToString();
                    }
                }
                CreateSummaryLog();
                Support.GetEmbeddedFile("SeleniumInternalHelpersSupportLibrary", "XSL.Summary.xsl", _resultsdir + "\\Summary.xsl");
                Support.GetEmbeddedFile("SeleniumInternalHelpersSupportLibrary", "XSL.Details.xsl", _resultsdir + "\\Details.xsl");
                Support.GetEmbeddedFile("SeleniumInternalHelpersSupportLibrary", "XSL.dbgstyle.css", _resultsdir + "\\dbgstyle.css");
            }
            else
            {
                Directory.CreateDirectory(_resultsdir + "\\Screenshots\\" + _testname);
                _debugLog = _resultsdir + "\\" + resultfile;
                CreateTestNode();
                CreateDebugLog();
            }

        }
        #endregion

        #region CreateTestNode
        private static void CreateTestNode()
        {

            XmlDocument doc = new XmlDocument();
            doc.Load(SummaryLog);

            XmlNode xNode = doc.GetElementsByTagName("tests")[0];

            XmlNode testNode = doc.CreateElement("codedui");
            XmlAttribute Valueattr = doc.CreateAttribute("name");
            Valueattr.Value = _testname;
            testNode.Attributes.Append(Valueattr);
            xNode.AppendChild(testNode);

            XmlNode stestid = doc.CreateElement("testid");
            stestid.InnerText = _testid;
            testNode.AppendChild(stestid);

            XmlNode sDesc = doc.CreateElement("sDesc");
            sDesc.InnerText = "description";
            testNode.AppendChild(sDesc);

            startTime = DateTime.Now;
            XmlNode stTime = doc.CreateElement("starttime");
            stTime.InnerText = startTime.ToString();
            testNode.AppendChild(stTime);

            XmlNode sStatus = doc.CreateElement("status");
            sStatus.InnerText = "InProgress";
            testNode.AppendChild(sStatus);

            XmlNode sFile = doc.CreateElement("file");
            sFile.InnerText = resultfile;
            testNode.AppendChild(sFile);

            doc.Save(SummaryLog);
        }
        #endregion

        #region UpdateResult
        ///<summary>
        ///<para>Updates Result of Test Method in the Reports. This must be called as part of Test Clean up.</para>
        ///<para>Example: Reports.UpdateResult(TestContext);</para>
        ///</summary>
        public static void UpdateResult(TestContext tContext)
        {
            string sResult = tContext.CurrentTestOutcome.ToString();
            string codeduiResult = "Passed";
            if (sResult.Equals("Passed") && TestResult)
            {
                codeduiResult = "Passed";
            }
            else if (!TestResult)
            {
                codeduiResult = "Failed";
            }
            else
            {
                codeduiResult = sResult;
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(SummaryLog);

            doc.SelectSingleNode("tests/codedui[@name='" + _testname + "']/status").InnerText = "complete";

            XmlNode XNode = doc.SelectSingleNode("/tests/codedui[@name='" + _testname + "']");

            XmlNode tResult = doc.CreateElement("result");
            tResult.InnerText = codeduiResult;
            XNode.AppendChild(tResult);

            endTime = DateTime.Now;
            XmlNode eTime = doc.CreateElement("endtime");
            eTime.InnerText = endTime.ToString();
            XNode.AppendChild(eTime);

            XmlNode rTime = doc.CreateElement("runtime");
            rTime.InnerText = ((int)((endTime - startTime).TotalSeconds)).ToString();
            XNode.AppendChild(rTime);

            doc.Save(SummaryLog);

            string reason = Support.OverallErrorMessage == "" ? "See detailed report." : Support.OverallErrorMessage;
            if (codeduiResult == "Failed")
                
                Assert.Fail(reason);
        }
        #endregion

        #region Result
        ///<summary>
        ///<para>Returns "pass" for true. "fail" for false.</para>
        ///<para>Example: string actulresult = Reports.Result(true);</para>
        ///</summary>
        public static string Result(bool iResult)
        {
            if (iResult)
                return "pass";
            else
                return "fail";

        }
        #endregion

        #region CreateSummaryLog
        private static void CreateSummaryLog()
        {
            string sTime = DateTime.Now.ToString().Replace("/", "").Replace(":", "").Replace(" ", "");
            //RUNRESULTDIR = _resultsdir + "\\" + sTime;
            Directory.CreateDirectory(_resultsdir + "\\Screenshots\\" + _testname);
            _summaryLogFile = "TESTSUMMARY_" + sTime + ".xml";
            SummaryLog = _resultsdir + "\\" + _summaryLogFile;//" + sFileName + ".xml";//"DebugLog.xml";
            XmlDocument doc = new XmlDocument();
            FileStream rfile = new FileStream(SummaryLog, FileMode.Create);

            XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(docNode);

            XmlProcessingInstruction xProcess = doc.CreateProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"Summary.xsl\"");
            doc.AppendChild(xProcess);

            XmlNode productsNode = doc.CreateElement("tests");
            doc.AppendChild(productsNode);

            XmlNode agtNode = doc.CreateElement("agentname");
            agtNode.InnerText = agentName;
            productsNode.AppendChild(agtNode);

            XmlNode buildNode = doc.CreateElement("buildnumber");
            buildNode.InnerText = buildNumber;
            productsNode.AppendChild(buildNode);

            XmlNode planNode = doc.CreateElement("testplanid");
            planNode.InnerText = testplanid;
            productsNode.AppendChild(planNode);

            XmlNode testClassNode = doc.CreateElement("testclass");
            testClassNode.InnerText = prevbin;
            productsNode.AppendChild(testClassNode);

            XmlNode testNode = doc.CreateElement("codedui");
            XmlAttribute Valueattr = doc.CreateAttribute("name");
            Valueattr.Value = _testname;
            testNode.Attributes.Append(Valueattr);
            productsNode.AppendChild(testNode);

            XmlNode stestid = doc.CreateElement("testid");
            stestid.InnerText = _testid;
            testNode.AppendChild(stestid);

            XmlNode sDesc = doc.CreateElement("sDesc");
            sDesc.InnerText = "description";
            testNode.AppendChild(sDesc);

            startTime = DateTime.Now;
            XmlNode stTime = doc.CreateElement("starttime");
            stTime.InnerText = startTime.ToString();
            testNode.AppendChild(stTime);

            XmlNode sStatus = doc.CreateElement("status");
            sStatus.InnerText = "InProgress";
            testNode.AppendChild(sStatus);

            XmlNode sFile = doc.CreateElement("file");
            sFile.InnerText = resultfile;
            testNode.AppendChild(sFile);

            doc.Save(rfile);
            rfile.Close();
            _debugLog = _resultsdir + "\\" + resultfile;
            CreateDebugLog();
        }
        #endregion

        #region CreateDebugLog
        private static void CreateDebugLog()
        {
            XmlDocument doc = new XmlDocument();
            FileStream rfile = new FileStream(_debugLog, FileMode.Create);

            XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(docNode);

            XmlProcessingInstruction xProcess = doc.CreateProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"Details.xsl\"");
            doc.AppendChild(xProcess);

            XmlNode productsNode = doc.CreateElement("testdetails");
            doc.AppendChild(productsNode);

            XmlNode tNode = doc.CreateElement("test");
            XmlAttribute nameattr = doc.CreateAttribute("name");
            nameattr.Value = _testname;
            tNode.Attributes.Append(nameattr);
            productsNode.AppendChild(tNode);

            doc.Save(rfile);
            rfile.Close();
        }
        #endregion

        #region StatusUpdate
        ///<summary>
        ///<para>Writes Description with Pass / Fail in the Report</para>
        ///<para>Example: Reports.StatusUpdate("Verify Order Creation in Application",false);</para>
        ///</summary>
        public static void StatusUpdate(string controlDescription, bool status, string controlType = "", string action = "", string property = "", string expectedValue = "", string actualValue = "", string errorMessage = "")
        {
            if (Support.bStartReporting)
            {
                try
                {
                    Reports.UpdateDebugLog(controlDescription, controlType, action, property, expectedValue, actualValue, Reports.Result(status), errorMessage);
                    Assert.AreEqual(true, status, controlDescription);
                }
                catch { Reports.TestResult = false; }
            }
        }
        #endregion

        #region UpdateDebugLog
        ///<summary>
        ///<para>Do not use. Instead use StatusUpdate</para>
        ///</summary>
        public static void UpdateDebugLog(string Control, string ControlType, string Method, string Property, string Value, string AValue, string Result, string Error)
        {
            CaptureImage();
            XmlDocument doc = new XmlDocument();
            doc.Load(_debugLog);

            XmlNode xNode = doc.SelectSingleNode("/testdetails/test[@name='" + _testname + "']");

            if (!xNode.HasChildNodes)
            {
                XmlNode descNode = doc.CreateElement("description");
                descNode.InnerText = TestDescription;
                xNode.AppendChild(descNode);

                // for PrintLog.exe
                string testDesc = "\t" + TestDescription;
                string TestDescBorder = new String('*', testDesc.Length + 2);
                PrintLog(TestDescBorder + Environment.NewLine + "* " + testDesc + Environment.NewLine + TestDescBorder);

                XmlDocument docSummary = new XmlDocument();
                docSummary.Load(SummaryLog);

                XmlNode testNode = docSummary.DocumentElement.SelectSingleNode("/tests/codedui/sDesc");

                XmlNode parNode = testNode.ParentNode;
                parNode.RemoveChild(testNode);

                XmlNode sDesc = docSummary.CreateElement("description");
                sDesc.InnerText = TestDescription;
                parNode.AppendChild(sDesc);

                docSummary.Save(SummaryLog);
            }

            if (prevdesc != TestStep)
            {
                TestStep = TestStep.Replace("'", "");
                TestStepNumber = TestStepNumber + 1;

                XmlNode tStep = doc.CreateElement("teststep");

                XmlAttribute teststepdescattr = doc.CreateAttribute("description");
                teststepdescattr.Value = TestStepNumber + ". " + TestStep;
                XmlAttribute testStepNumber = doc.CreateAttribute("stepnumber");
                testStepNumber.Value = TestStepNumber.ToString();

                PrintLog(TestStepNumber + ". " + TestStep);     // for PrintLog.exe 

                prevdesc = TestStep;

                tStep.Attributes.Append(teststepdescattr);
                tStep.Attributes.Append(testStepNumber);

                xNode = xNode.AppendChild(tStep);
            }
            else
            {
                xNode = doc.SelectSingleNode("/testdetails/test[@name='" + _testname + "']/teststep[@description='" + TestStepNumber + ". " + TestStep + "']");
            }

            XmlNode stmtNode = doc.CreateElement("dbg");

            XmlAttribute Controlattr = doc.CreateAttribute("Control");
            Controlattr.Value = Control;

            XmlAttribute ControlTypeattr = doc.CreateAttribute("ControlType");
            ControlTypeattr.Value = ControlType;

            XmlAttribute Methodattr = doc.CreateAttribute("Method");
            Methodattr.Value = Method;

            XmlAttribute Propertyattr = doc.CreateAttribute("Property");
            Propertyattr.Value = Property;

            XmlAttribute Valueattr = doc.CreateAttribute("Value");
            Valueattr.Value = Value;

            XmlAttribute AValueattr = doc.CreateAttribute("AValue");
            AValueattr.Value = AValue;

            XmlAttribute Resultattr = doc.CreateAttribute("Result");
            Resultattr.Value = Result;

            XmlAttribute Errorattr = doc.CreateAttribute("Error");
            Errorattr.Value = Error;

            XmlAttribute Screenattr = doc.CreateAttribute("Screenshot");
            Screenattr.Value = _screenshotpath;
            _screenshotpath = "";

            Support.ctrlendTime = DateTime.Now;
            XmlAttribute stepTimeattr = doc.CreateAttribute("stepTime");
            if (ControlType != "")
                stepTimeattr.Value = ((int)((Support.ctrlendTime - Support.ctrlstartTime).TotalSeconds)).ToString();
            else
                stepTimeattr.Value = "";
            //General.ctrlstartTime = DateTime.Now;

            stmtNode.Attributes.Append(Controlattr);
            stmtNode.Attributes.Append(ControlTypeattr);
            stmtNode.Attributes.Append(Methodattr);
            stmtNode.Attributes.Append(Propertyattr);
            stmtNode.Attributes.Append(Valueattr);
            stmtNode.Attributes.Append(AValueattr);
            stmtNode.Attributes.Append(Resultattr);
            stmtNode.Attributes.Append(Errorattr);
            stmtNode.Attributes.Append(stepTimeattr);
            stmtNode.Attributes.Append(Screenattr);


            xNode.AppendChild(stmtNode);

            doc.Save(_debugLog);
        }
        #endregion

        #region PrintLog
        /// <summary>
        ///    Display message/text on the PrintLog window (require manual start/run the PrintLog.exe)
        /// </summary>
        /// <param name="message">message or text to be displayed on the PrintLog window</param>
        /// <returns>None</returns>
        public static void PrintLog(string message)
        {
            FAF.PrintLog.PrintLog.Print(message);
        }
        #endregion
    }
}
