﻿using SeleniumInternalHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumInternalHelpersSupportLibrary
{
    public class PageObjectInteractionsFASTReporter : IPageObjectReporter
    {
        public void ReportAction(string description, string argument)
        {
            Reports.UpdateDebugLog("", "Driver", description, "", argument, "", Reports.Result(true), "");
        }

        public void ReportStep(string description)
        {
            Reports.TestStep = description;
        }
    }
}
