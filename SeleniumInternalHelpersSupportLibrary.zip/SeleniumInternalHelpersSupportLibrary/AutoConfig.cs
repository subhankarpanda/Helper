﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SeleniumInternalHelpersSupportLibrary
{
    public static class AutoConfig
    {
        public static void Initialize()
        {
            fastHomeUrl = ReadConfig("WEBSITE > Home", () => GetRunCategoryOption("WEBSITE", "Home"));
            fastAdmUrl = ReadConfig("WEBSITE > FASTADM_URL", () => GetRunCategoryOption("WEBSITE", "FASTADM_URL"));
            fastCsUrl = ReadConfig("WEBSITE > FASTCS", () => GetRunCategoryOption("WEBSITE", "FASTCS"));
            fastWebUrl = ReadConfig("WEBSITE > FASTWEB", () => GetRunCategoryOption("WEBSITE", "FASTWEB"));

            userName = ReadConfig("User_Name", () => GetRunOption("User_Name"));
            userPassword = Support.Decrypt(ReadConfig("User_Password", () => GetRunOption("User_Password")));
            userName1 = ReadConfig("User_Name1", () => GetRunOption("User_Name1"));
            userPassword1 = Support.Decrypt(ReadConfig("User_Password1", () => GetRunOption("User_Password1")));
            userNameSU = ReadConfig("User_Name2", () => GetRunOption("User_Name2"));
            userPasswordSU = Support.Decrypt(ReadConfig("User_Password2", () => GetRunOption("User_Password2")));

            waitTime = ReadConfig("SyncTimeOut", () => GetRunOption("SyncTimeOut"));

            interfaceURL = ReadConfig("Interface_Url", () => GetRunOption("Interface_Url"));
            interfaceUsername = ReadConfig("Interface_UserName", () => GetRunOption("Interface_UserName"));
            interfaceUserPassword = Support.Decrypt(ReadConfig("Interface_UserPassword", () => GetRunOption("Interface_UserPassword")));
            interfaceUserDomain = ReadConfig("Interface_UserDomain", () => GetRunOption("Interface_UserDomain"));

            useCDRegion = ReadConfig("IMD_CDRegionSelection", () => GetRunOption("IMD_CDRegionSelection"));
            formType = ReadConfig("IMD_FormType", () => GetRunOption("IMD_FormType"));
            selectedRegionBUID = ReadConfig("IMD_Region_BUID", () => GetRunOption("IMD_Region_BUID"));
            selectedOfficeBUID = ReadConfig("IMD_Region_Office_BUID", () => GetRunOption("IMD_Region_Office_BUID"));
            selectedRegionName = ReadConfig("IMD_Region", () => GetRunOption("IMD_Region"));
            selectedOfficeName = ReadConfig("IMD_Region_Office", () => GetRunOption("IMD_Region_Office"));

            deliverEmailTo = ReadConfig("DELIVERY_MAIL_TO", () => GetRunOption("DELIVERY_MAIL_TO"));
            deliverFaxTo = ReadConfig("DELIVERY_FAX_TO", () => GetRunOption("DELIVERY_FAX_TO"));
            checkPrintingPassword = ReadConfig("CHECK_PRINTING_PASSWARD", () => GetRunOption("CHECK_PRINTING_PASSWARD"));

            wfeServerName = ReadConfig("WFE_ServerName", () => GetRunOption("WFE_ServerName"));
            wfeUserName = ReadConfig("WFE_UserName", () => GetRunOption("WFE_UserName"));
            wfePassword = Support.Decrypt(ReadConfig("WFE_Password", () => GetRunOption("WFE_Password")));
            wfeDomain = ReadConfig("WFE_Domain", () => GetRunOption("WFE_Domain"));

            string pass = ReadConfig("SQL > Password", () => GetRunCategoryOption("SQL", "Password"), required: false);
            fastProdConnectionString = pass == "" ? "No password provided in SQL config." : string.Format(ReadConfig("SQL > ConnectionString", () => GetRunCategoryOption("SQL", "ConnectionString"), required: false), Support.Decrypt(pass));
        }

        #region private members
        private static string fastHomeUrl;
        private static string fastAdmUrl;
        private static string fastCsUrl;
        private static string fastWebUrl;

        private static string userName;
        private static string userPassword;
        private static string userName1;
        private static string userPassword1;
        private static string userNameSU;
        private static string userPasswordSU;

        private static string waitTime;

        private static string interfaceURL;
        private static string interfaceUsername;
        private static string interfaceUserPassword;
        private static string interfaceUserDomain;

        private static string useCDRegion;
        private static string formType;
        private static string selectedRegionBUID;
        private static string selectedOfficeBUID;
        private static string selectedRegionName;
        private static string selectedOfficeName;

        private static string deliverEmailTo;
        private static string deliverFaxTo;
        private static string checkPrintingPassword;

        private static string wfeServerName;
        private static string wfeUserName;
        private static string wfePassword;
        private static string wfeDomain;

        private static string fastProdConnectionString;
        #endregion

        #region public members
        public static string FASTHomeURL { get { return fastHomeUrl; } }
        public static string FASTAdmURL { get { return fastAdmUrl; } }
        public static string FASTCsUrl { get { return fastCsUrl; } }
        public static string FASTWebURL { get { return fastWebUrl; } }
        public static string UserName { get { return userName; } }
        public static string UserPassword { get { return userPassword; } }
        public static string WaitTime { get { return waitTime; } }
        public static string UserNameSecondary { get { return userName1; } }
        public static string UserPasswordSecondary { get { return userPassword1; } }
        public static string UserNameSU { get { return userNameSU; } }
        public static string UserPasswordSU { get { return userPasswordSU; } }
        public static string InterfaceURL { get { return interfaceURL; } }
        public static string InterfaceUsername { get { return interfaceUsername; } }
        public static string InterfaceUserPassword { get { return interfaceUserPassword; } }
        public static string InterfaceUserDomain { get { return interfaceUserDomain; } }
        public static bool UseCDRegion { get { return bool.Parse(useCDRegion); } }
        public static bool UseCDFormType { get { return formType == "CD"; } }
        public static string FormType { get { return formType; } }
        public static string SelectedRegionBUID { get { return selectedRegionBUID; } }
        public static string SelectedOfficeBUID { get { return selectedOfficeBUID; } }
        public static string SelectedRegionName { get { return selectedRegionName; } }
        public static string SelectedOfficeName { get { return selectedOfficeName; } }
        public static string DeliverEmailTo { get { return deliverEmailTo; } }
        public static string DeliverFaxTo { get { return deliverFaxTo; } }
        public static string CheckPrintingPassword { get { return checkPrintingPassword; } }
        public static string WFEServerName { get { return wfeServerName; } }
        public static string WFEUserName { get { return wfeUserName; } }
        public static string WFEPassword { get { return wfePassword; } }
        public static string WFEDomain { get { return wfeDomain; } }
        public static string FASTPRODConnectionString { get { return fastProdConnectionString; } }
        #endregion

        private static string ReadConfig(string key, Func<string> readConfig, bool required = true)
        {
            string configValue = "";
            try
            {
                configValue = readConfig.Invoke();
            }
            catch (Exception)
            {
                if (required)
                    throw new Exception(string.Format("There was an error reading the selected environment from AutoConfig.XML. {0} key not found.", key));
            }

            if (configValue == string.Empty && required)
                throw new Exception(string.Format("Please provide a config value for key '{0}' under environment '{1}' in AutoConfig.XML.", key, Support.TESTENVIRONMENT));

            return configValue;
        }

        #region GetRunCategoryOption
        ///<summary>
        ///<para>Gets value of key under the category option under Environment specified from the AutoConfig.xml.</para>
        ///<para>Example: string HomeURL = GetRunCategoryOption("WEBSITE","Home");</para>
        ///</summary>
        private static string GetRunCategoryOption(string option, string key)
        {
            string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
            string sValue = ReadXMLConfiguration(ConfigPath, option, key);
            return sValue;

        }
        #endregion

        #region GetRunOption
        ///<summary>
        ///<para>Gets value of key under the category "option" under Environment specified from the AutoConfig.xml.</para>
        ///<para>Example: string UserId = General.GetRunOption("User_Name");</para>
        ///</summary>
        private static string GetRunOption(string key)
        {
            string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
            string sValue = ReadXMLConfiguration(ConfigPath, "Option", key);
            return sValue;
        }
        #endregion

        #region ReadXMLConfiguration
        private static string ReadXMLConfiguration(string ConfigPath, string option, string key)
        {
            string sValue = "";
            XmlDocument xDoc = new XmlDocument();
            if (File.Exists(ConfigPath))
            {
                xDoc.Load(ConfigPath);
                if (xDoc.DocumentElement.SelectSingleNode(Support.TESTENVIRONMENT + "/" + option + "/" + key) != null)
                    sValue = xDoc.DocumentElement.SelectSingleNode(Support.TESTENVIRONMENT + "/" + option + "/" + key).InnerText.ToString();
            }
            return sValue;
        }
        #endregion

    }
}