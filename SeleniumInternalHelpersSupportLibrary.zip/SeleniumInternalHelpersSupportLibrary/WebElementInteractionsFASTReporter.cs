﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumInternalHelpersSupportLibrary
{
    using OpenQA.Selenium;
    using SeleniumInternalHelpers;

    public class WebElementInteractionsFASTReporter : IWebElementReporter
    {
        public void Click(IWebElement target)
        {
            ReportAction(target, "Click");
        }

        public void FindElements(IWebElement target, string FindArgument)
        {
           
            //If the find element function is invoked using the following xpath then it is safe to assume we are trying to set the value of a drop down box
            const string SearchCriteriaUsedBySelectElement = "By.XPath: .//option[normalize-space(.) =";

            if (FindArgument.Contains(SearchCriteriaUsedBySelectElement))
            {
                //Extract desired set value by removing
                var desiredDropDownSelection =
                    FindArgument.Replace("By.XPath: .//option[normalize-space(.) = \"", string.Empty)
                        .Replace("\"]", string.Empty);

                string targetInformation = target.GetAttribute("Id") ?? target.GetAttribute("Name");

                //Replace this with reporting implementation
                Console.WriteLine(
                    "Selecting dropdown value {0} on web element: {1}",
                    desiredDropDownSelection,
                    targetInformation);
            }
        }

        public void SendKeys(IWebElement target, string keys)
        {
            ReportAction(target, "Set text", keys);
        }

        public void Submit(IWebElement target)
        {
            ReportAction(target, "Submit");
        }

        //Code taken from current report object. May need to be revised for stability.
        private void ReportAction(IWebElement target, string action, string value = "")
        {
            Support.ctrlstartTime = DateTime.Now;
            var controlName = target.GetAttribute("Name") ?? target.GetAttribute("Id");
            controlName = (controlName == null) ? target.Text : controlName;
            var tagName = target.TagName;

            Reports.UpdateDebugLog(controlName, tagName, action, string.Empty, value, string.Empty, Reports.Result(true), string.Empty);
        }
    }
}
