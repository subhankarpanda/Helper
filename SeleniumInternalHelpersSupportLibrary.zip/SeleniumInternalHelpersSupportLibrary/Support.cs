﻿using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using System.Xml;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Net.Mail;
using System.Xml.XPath;
using Microsoft.XmlDiffPatch;
using System.Runtime.Serialization;
using System.Security.Cryptography;

namespace SeleniumInternalHelpersSupportLibrary
{
    public class Support
    {
        public static Exception defaultException = new Exception();
        public static MouseButtons MOUSE_BUTTON = MouseButtons.Left;
        public static ModifierKeys MODIFIER_KEY = ModifierKeys.None;
        public static string GeneralMessage = "";
        public static string MIC_CLASS = "";
        public static string OBJ_PARENT = "";
        public static string OBJECT_MAP = "";
        public static XmlElement OBJ_PARENT_ELEMENT = null;
        public static string value = "";
        public static string data = "";
        public static string controlname = "";
        public static string TESTENVIRONMENT = "";
        public static int ControlTimeOut = 10000;
        public static bool IsParentSet = true;
        public static UITestControl ToCaptureScreenshot = null;
        //public static HtmlControl TempControl = (HtmlControl)UITestControl.Desktop;
        public static DateTime ctrlstartTime = new DateTime();
        public static DateTime ctrlendTime = new DateTime();
        public static string shouldusewaitforreadylevel = "yes";
        public static int syncTimeout = 10000;
        public static bool bCloseDlg = true;
        public static bool bStartReporting = false;
        public static string FASTWindowName = "FAST v10.0";
        public static string NoTitleWindow = "~notitle";
        public static StringHelper stringHelper = null;
        public static string OverallErrorMessage = "";
        //public static bool IsToRemoveNewLineChars { get { return IsToRemoveNewLineChars; } set { IsToRemoveNewLineChars = false; } }
        public static RegexOptions regExpOptions;

        public enum XmlComareOptions
        {
            None = 0,
            IgnoreChildOrder = 1,
            IgnoreComments = 2,
            IgnorePI = 4,
            IgnoreWhitespace = 8,
            IgnoreNamespaces = 16,
            IgnorePrefixes = 32,
            IgnoreXmlDecl = 64,
            IgnoreDtd = 128,
        }


        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        #region Write XML Response to String
        public static string WriteXMLResponseToString(object resp)
        {

            DataContractSerializer writer = new DataContractSerializer(resp.GetType());
            MemoryStream stream = new MemoryStream();
            writer.WriteObject(stream, resp);
            string xmlString = Encoding.UTF8.GetString(stream.ToArray());

            return xmlString;
        }


        #endregion

        #region Writing value to IniFile by passing IniPath, Section, Key, Value
        ///<summary>
        ///<para>Writes the value of a key under the given section of the IniFile</para>
        ///<para>Example: SeleniumInternalHelpersSupportLibrary.General.IniWriteValue(path, section, key, value);</para>
        ///</summary>
        public static void IniWriteValue(string path, string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, path);
        }
        #endregion

        #region Reading value from IniFile by passing IniPath, Section, Key
        ///<summary>
        ///<para>Gets the value of the key under the given section of the IniFile</para>
        ///<para>Example: SeleniumInternalHelpersSupportLibrary.General.IniReadValue(path, section, key);k</para>
        ///</summary>
        public static string IniReadValue(string path, string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, "", temp, 255, path);
            return temp.ToString();
        }
        #endregion

        #region Match
        ///<summary>
        ///     Evaluate whether some text match an expression.
        ///     Example: General.Match("Order[0-9]?","Order1");
        ///</summary>
        public static void Match(string regEx, string input, string property = "", RegexOptions regExOptions = RegexOptions.None)
        {
            if (stringHelper != null)
            {
                input = stringHelper.CleanUp(input);
            }
            try
            {
                var match = Regex.Match(input, regEx, regExOptions);
                if (match.Success)
                {
                    Reports.UpdateDebugLog("Verify", "", "Match", property, match.Value, match.Value, Reports.Result(true), "");
                }
                else
                {
                    throw new Exception("No match was found");
                }
            }
            catch (Exception ex)
            {
                Reports.UpdateDebugLog("Verify", "", "Match", property, regEx, input, Reports.Result(false), ex.Message);
                Reports.TestResult = false;
            }
        }
        #endregion

        #region RemoveNewLineCharacters
        public static string RemoveNewLineChars(string testData)
        {
            testData = testData.Replace("\r\n", "");
            testData = Regex.Replace(testData, @"\r\n?|\n", "");
            testData = testData.Replace(Environment.NewLine, "");
            return testData;
        }
        #endregion

        #region Fail
        ///<summary>
        ///<para>Compares two string values for equal.</para>
        ///<para>Example: General.AreEqual("Order","Order1");</para>
        ///</summary>
        public static void Fail(string sMessage)
        {
            OverallErrorMessage = sMessage;
            //Reports.CaptureImage();
            Reports.UpdateDebugLog("Error Occured", "", "Fail", "", "", "", Reports.Result(false), sMessage);
            Reports.TestResult = false;
        }
        #endregion

        #region AreEqual
        ///<summary>
        ///<para>Compares two string values for equal.</para>
        ///<para>Example: General.AreEqual("Order","Order1");</para>
        ///</summary>
        public static void AreEqual(string exp, string actual, string property = "*", bool bIgnoreCase = false)
        {
            if (stringHelper != null)
            {
                exp = stringHelper.CleanUp(exp);
                actual = stringHelper.CleanUp(actual);
            }
            if (bIgnoreCase)
            {
                exp = exp.ToLowerInvariant();
                actual = actual.ToLowerInvariant();
            }

            AreEqual((object)exp, (object)actual, property);
        }

        /// <summary>
        /// Verifies that two specified object are equal
        /// </summary>
        /// <param name="exp">Expected Object</param>
        /// <param name="actual">Actual Object</param>
        /// <param name="property">Report's Property value</param>
        public static void AreEqual(object exp, object actual, string property)
        {
            try
            {
                Assert.AreEqual(exp, actual);
                Reports.UpdateDebugLog("Verify", "", "AreEqual", property, "" + exp, "" + actual, Reports.Result(exp.Equals(actual)), "");
            }
            catch
            {
                Reports.UpdateDebugLog("Verify", "", "AreEqual", property, "" + exp, "" + actual, Reports.Result(false), "");
                Reports.TestResult = false;
            }
        }

        public static void AreEqual(string exp, string actual, bool ignoreCase)
        {
            AreEqual(exp, actual, property: "*", bIgnoreCase: ignoreCase);
        }
        #endregion

        #region IsTrue
        ///<summary>
        ///<para>Compares two string values for equal.</para>
        ///<para>Example: General.AreEqual("Order","Order1");</para>
        ///</summary>
        public static void IsTrue(bool condition, string message)
        {
            try
            {
                Reports.UpdateDebugLog("Verify: " + message, "", "IsTrue", "", "", "", Reports.Result(condition), "");
                Assert.IsTrue(condition, message);
            }
            catch { Reports.TestResult = false; }
        }
        #endregion

        #region AreNotEqual
        ///<summary>
        ///<para>Compares two string values for not equal.</para>
        ///<para>Example: General.AreNotEqual("Order","Order1");</para>
        ///</summary>
        public static void AreNotEqual(string exp, string actual, bool bIgnoreCase = false)
        {
            try
            {
                if (bIgnoreCase)
                    Reports.UpdateDebugLog("Verify", "", "AreNotEqual", "", exp, actual, Reports.Result(!exp.ToLower().Equals(actual.ToLower())), "");
                else
                    Reports.UpdateDebugLog("Verify", "", "AreNotEqual", "", exp, actual, Reports.Result(!exp.Equals(actual)), "");
                Assert.AreNotEqual(exp, actual, bIgnoreCase);
            }
            catch { Reports.TestResult = false; }
        }
        #endregion

        #region AreNotEqual
        ///<summary>
        ///<para>Compares two string values for not equal.</para>
        ///<para>Example: General.AreNotEqual("Order","Order1");</para>
        ///</summary>
        public static void AreNotEqual(string exp, string actual, string property)
        {
            try
            {
                Reports.UpdateDebugLog("Verify", "", "AreNotEqual", property, exp, actual, Reports.Result(!exp.Equals(actual)), "");
                Assert.AreNotEqual(exp, actual);
            }
            catch { Reports.TestResult = false; }
        }
        #endregion

        #region AreEqualTrim
        ///<summary>
        ///<para>Compares two string values for equal after Trim.</para>
        ///<para>Example: General.AreEqualTrim("Order","Order1");</para>
        ///</summary>
        public static void AreEqualTrim(string exp, string actual)
        {
            try
            {
                Reports.UpdateDebugLog("Verify", "", "AreEqualTrim", "", exp, actual, Reports.Result(exp.Trim().Equals(actual.Trim())), "");
                Assert.AreEqual(exp.Trim(), actual.Trim());
            }
            catch { Reports.TestResult = false; }
        }
        #endregion

        #region Eval
        public static void Eval<T>(Action expression, bool exceptionExpected = true, string reportMessage = "Evaluate Expression") where T : Exception
        {
            try
            {
                expression.Invoke();
                Reports.UpdateDebugLog("Verify:" + reportMessage, "", "Eval", "", "", "", Reports.Result(!exceptionExpected), "");
                Reports.TestResult = !exceptionExpected;
            }
            catch (T)
            {
                Reports.UpdateDebugLog("Verify:" + reportMessage, "", "Eval", "", "", "", Reports.Result(exceptionExpected), "");
                Reports.TestResult = exceptionExpected;
            }
        }
        #endregion

        //Move to AutoConfig class

        //#region GetRunCategoryOption
        /////<summary>
        /////<para>Gets value of key under the category option under Environment specified from the AutoConfig.xml.</para>
        /////<para>Example: string HomeURL = GetRunCategoryOption("WEBSITE","Home");</para>
        /////</summary>
        //public static string GetRunCategoryOption(string option, string key)
        //{
        //    string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
        //    string sValue = ReadXMLConfiguration(ConfigPath, option, key);
        //    return sValue;

        //}
        //#endregion


        #region ReadAppSettings
        ///<summary>
        ///<para>Gets value of key under the category option under AppSettings specified from the AutoConfig.xml.</para>
        ///<para>Example: string Environment = General.ReadAppSettings("AppSettings","Environment");</para>
        ///</summary>
        public static string ReadAppSettings(string option, string key)
        {
            string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
            string sValue = ReadXMLAppSettings(ConfigPath, option, key);
            return sValue;

        }
        #endregion

        //Move to AutoConfig class

        //#region ReadXMLConfiguration
        //private static string ReadXMLConfiguration(string ConfigPath, string option, string key)
        //{
        //    string sValue = "";
        //    XmlDocument xDoc = new XmlDocument();
        //    if (File.Exists(ConfigPath))
        //    {
        //        xDoc.Load(ConfigPath);
        //        if (xDoc.DocumentElement.SelectSingleNode(Support.TESTENVIRONMENT + "/" + option + "/" + key) != null)
        //            sValue = xDoc.DocumentElement.SelectSingleNode(Support.TESTENVIRONMENT + "/" + option + "/" + key).InnerText.ToString();
        //    }
        //    return sValue;
        //}
        //#endregion

        #region ReadXML
        public static string ReadXML(string XMLFileWithPath, string xPath)
        {
            string sValue = "";
            XmlDocument xDoc = new XmlDocument();
            if (File.Exists(XMLFileWithPath))
            {
                xDoc.Load(XMLFileWithPath);
                sValue = xDoc.DocumentElement.SelectSingleNode(xPath).InnerText.Trim();
            }
            return sValue;
        }
        #endregion

        #region ReadXML
        public static string ReadXMLUsingXpath(string XMLFileWithPath, string xPath, bool refiFile = false, string defaultns = "http://www.firstam.com/2011/07/DataContract/FAST", bool addNsPrefix = true, string nsPrefix = "xsd")
        {
            string sValue = "";

            if (refiFile)
                xPath = xPath.Replace("/CalculateCashToClose/", "/AlternateCalculateCashToClose/");

            XmlDocument document = new XmlDocument();
            document.Load(XMLFileWithPath);
            XPathNavigator navigator = document.CreateNavigator();

            XmlNamespaceManager nsManager = new XmlNamespaceManager(navigator.NameTable);
            nsManager.AddNamespace(nsPrefix, defaultns);

            if (addNsPrefix)
                xPath = xPath.Replace("/", "/" + nsPrefix + ":");

            try
            {
                sValue = document.SelectSingleNode(xPath, nsManager).InnerXml;
            }
            catch
            {
                sValue = "Can't locate xpath: " + xPath;
            }

            return sValue;
        }
        #endregion

        #region ReadSSPDF
        ///<summary>
        ///Read Settlement Statement PDF and return charge value based on charge description.
        /// PDFFileWithPath:Full path to the PDF file.
        /// searchString: The complete description of the charge on the Description column including any space.
        /// columnName: valid values are "SellerDebit", SellerCredit", "BuyerDebit", "BuyerCredit", "BuyerCharge", "SellerCharge".
        ///</summary>

        public static string ReadSSPDF(string PDFFileWithPath, string searchString, string columnName, bool combined = true, bool CD = true)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            string result = string.Empty;
            string text = string.Empty;

            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                text = text + PdfTextExtractor.GetTextFromPage(reader, i);
            }

            #region first try
            try
            {
                if (combined)
                {
                    if (columnName == "BuyerDebit" || columnName == "BuyerCredit" || columnName == "BuyerCharge")
                    {
                        int first = text.IndexOf(searchString) + searchString.Length;
                        int last = 0;
                        string str2 = "";

                        if (CD)
                        {
                            last = text.IndexOf("\n", first);
                            str2 = text.Substring(first, last - first).Trim();
                        }
                        else
                        {
                            last = text.LastIndexOf("\n", first);
                            str2 = text.Substring(last, (first - searchString.Length) - last).Trim();
                        }

                        char[] delimiterChar = { ' ' };

                        if (str2.Split(delimiterChar).Length == 1)
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "BuyerDebit" || columnName == "BuyerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "BuyerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else
                            result = "";
                    }
                    else if (columnName == "SellerDebit" || columnName == "SellerCredit" || columnName == "SellerCharge")
                    {
                        int first = text.IndexOf(searchString);
                        int last = 0;
                        string str2 = "";

                        if (CD)
                        {
                            if (searchString == "Due To Seller") //Special case 'Due To Seller' doesn't display charge correctly
                            {
                                searchString = "Due To Seller \n";
                                first = text.IndexOf(searchString);
                                last = text.IndexOf("\n", first + searchString.Length);
                                str2 = text.Substring(first + searchString.Length, last - (first + searchString.Length)).Trim();
                                if (str2 == "")
                                {
                                    searchString = "Due To Seller";
                                    first = text.IndexOf(searchString);
                                    last = text.LastIndexOf("\n", first);
                                    str2 = text.Substring(last, first - last).Trim();
                                }
                            }
                            else
                            {
                                last = text.LastIndexOf("\n", first);
                                str2 = text.Substring(last, first - last).Trim();
                            }
                        }
                        else
                        {
                            last = text.IndexOf("\n", first);
                            str2 = text.Substring(first + searchString.Length, last - (first + searchString.Length)).Trim();
                        }

                        char[] delimiterChar = { ' ' };

                        if (str2.Split(delimiterChar).Length == 1)
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "SellerDebit" || columnName == "SellerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "SellerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else
                            result = "";
                    }
                    else
                        result = "";
                }
                else
                {
                    if (columnName == "BuyerDebit" || columnName == "BuyerCharge" || columnName == "BuyerCredit" || columnName == "SellerDebit" || columnName == "SellerCredit" || columnName == "SellerCharge")
                    {
                        int first = text.IndexOf(searchString) + searchString.Length;
                        int last = text.IndexOf("\n", first);
                        string str2 = text.Substring(first, last - first).Trim();
                        char[] delimiterChar = { ' ' };

                        if (str2.Split(delimiterChar).Length == 1)
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "BuyerDebit" || columnName == "BuyerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "BuyerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "SellerDebit" || columnName == "SellerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "SellerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else
                            result = "";
                    }
                }
            }
            catch
            {
                result = "No match found!";
            }
            #endregion first try

            #region second try
            if (result == string.Empty)
            {
                searchString = searchString + " \n"; //Sometimes it adds a new line character after the search string!

                try
                {
                    if (combined)
                    {
                        if (columnName == "BuyerDebit" || columnName == "BuyerCredit" || columnName == "BuyerCharge")
                        {
                            int first = text.IndexOf(searchString) + searchString.Length;
                            int last = 0;
                            string str2 = "";

                            if (CD)
                            {
                                last = text.IndexOf("\n", first);
                                str2 = text.Substring(first, last - first).Trim();
                            }
                            else
                            {
                                //last = text.LastIndexOf("\n", first);
                                last = text.IndexOf("\n", first);
                                //str2 = text.Substring(last, (first - searchString.Length) - last).Trim();
                                str2 = text.Substring(first, (last - first)).Trim();
                            }

                            char[] delimiterChar = { ' ' };

                            if (str2.Split(delimiterChar).Length == 1)
                            {
                                result = str2.Split(delimiterChar)[0];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && (columnName == "BuyerDebit" || columnName == "BuyerCharge"))
                            {
                                result = str2.Split(delimiterChar)[0];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && columnName == "BuyerCredit")
                            {
                                result = str2.Split(delimiterChar)[1];
                            }
                            else
                                result = "";
                        }
                        else if (columnName == "SellerDebit" || columnName == "SellerCredit" || columnName == "SellerCharge")
                        {
                            //int first = text.IndexOf(searchString);
                            int first = text.IndexOf(searchString) + searchString.Length;
                            int last = 0;
                            string str2 = "";

                            if (CD)
                            {
                                if (searchString == "Due To Seller") //Special case 'Due To Seller' doesn't display charge correctly
                                {
                                    searchString = "Due To Seller \n";
                                    first = text.IndexOf(searchString);
                                    last = text.IndexOf("\n", first + searchString.Length);
                                    str2 = text.Substring(first + searchString.Length, last - (first + searchString.Length)).Trim();
                                    if (str2 == "")
                                    {
                                        searchString = "Due To Seller";
                                        first = text.IndexOf(searchString);
                                        last = text.LastIndexOf("\n", first);
                                        str2 = text.Substring(last, first - last).Trim();
                                    }
                                }
                                else
                                {
                                    last = text.LastIndexOf("\n", first);
                                    str2 = text.Substring(last, first - last).Trim();
                                }
                            }
                            else
                            {
                                last = text.IndexOf("\n", first);
                                //str2 = text.Substring(first + searchString.Length, last - (first + searchString.Length)).Trim();
                                str2 = text.Substring(first, (last - first)).Trim();
                            }

                            char[] delimiterChar = { ' ' };

                            if (str2.Split(delimiterChar).Length == 1)
                            {
                                //result = str2.Split(delimiterChar)[0];
                                result = str2.Split(delimiterChar)[2];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && (columnName == "SellerDebit" || columnName == "SellerCharge"))
                            {
                                //result = str2.Split(delimiterChar)[0];
                                result = str2.Split(delimiterChar)[2];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && columnName == "SellerCredit")
                            {
                                //result = str2.Split(delimiterChar)[1];
                                result = str2.Split(delimiterChar)[3];
                            }
                            else
                                result = "";
                        }
                        else
                            result = "";
                    }
                    else
                    {
                        if (columnName == "BuyerDebit" || columnName == "BuyerCharge" || columnName == "BuyerCredit" || columnName == "SellerDebit" || columnName == "SellerCredit" || columnName == "SellerCharge")
                        {
                            int first = text.IndexOf(searchString) + searchString.Length;
                            int last = text.IndexOf("\n", first);
                            string str2 = text.Substring(first, last - first).Trim();
                            char[] delimiterChar = { ' ' };

                            if (str2.Split(delimiterChar).Length == 1)
                            {
                                result = str2.Split(delimiterChar)[0];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && (columnName == "BuyerDebit" || columnName == "BuyerCharge"))
                            {
                                result = str2.Split(delimiterChar)[0];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && columnName == "BuyerCredit")
                            {
                                result = str2.Split(delimiterChar)[1];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && (columnName == "SellerDebit" || columnName == "SellerCharge"))
                            {
                                result = str2.Split(delimiterChar)[2];
                            }
                            else if (str2.Split(delimiterChar).Length > 1 && columnName == "SellerCredit")
                            {
                                result = str2.Split(delimiterChar)[3];
                            }
                            else
                                result = "";
                        }
                    }
                }
                catch
                {
                    result = "No match found!";
                }

            }
            #endregion second try

            return result;
        }
        #endregion

        #region ReadPDFFile
        ///<summary>
        ///Read the entire content of a PDF file and resturn a string contains all text in the PDF file.
        /// PDFFileWithPath:Full path to the PDF file.
        ///</summary>

        public static string ReadPdfFile(string PDFFileWithPath)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            string text = string.Empty;

            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                text = text + PdfTextExtractor.GetTextFromPage(reader, i);

            }

            reader.Close();
            return text;
        }

        public static string ReadPdfFile(string PDFFileWithPath, string From, string To)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            string text = string.Empty;

            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                text = text + PdfTextExtractor.GetTextFromPage(reader, i);
            }
            string[] educationTypeArr = text.Split(new string[] { From, To }, StringSplitOptions.None);
            text = educationTypeArr[1].Trim();

            reader.Close();
            return text;
        }

        public static string ReadPdfPageSize(string PDFFileWithPath)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            int pageNmbr = 1;
            iTextSharp.text.Rectangle pagesize = reader.GetPageSize(pageNmbr);

            reader.Close();
            return pagesize.ToString();
        }
        #endregion

        #region Add Business Day
        List<DateTime> holidays = new List<DateTime>()
        {
            // 2015 Holidays
             new DateTime(2015,01,01),
             new DateTime(2015,01,19),
             new DateTime(2015,02,16),
             new DateTime(2015,05,25),
             new DateTime(2015,07,04),
             new DateTime(2015,09,07),
             new DateTime(2015,10,12),
             new DateTime(2015,11,11),
             new DateTime(2015,11,26),
             new DateTime(2015,12,25),
             // 2016 Holidays
             new DateTime(2016,01,01),
             new DateTime(2016,01,18),
             new DateTime(2016,02,15),
             new DateTime(2016,05,30),
             new DateTime(2016,07,04),
             new DateTime(2016,09,05),
             new DateTime(2016,10,10),
             new DateTime(2016,11,11),
             new DateTime(2016,11,24),
             new DateTime(2016,12,25)
             
             // TODO: Need to read from xml and populate the list
        };
        public static DateTime AddBusinessDaysExcludeHolidays(DateTime fromDate, int numberofWorkDays,
                                   ICollection<DateTime> holidays)
        {
            var futureDate = fromDate;
            for (var i = 0; i < numberofWorkDays; i++)
            {
                if (//futureDate.DayOfWeek == DayOfWeek.Saturday
                   futureDate.DayOfWeek == DayOfWeek.Sunday
                   || (holidays != null && holidays.Contains(futureDate)))
                {
                    futureDate = futureDate.AddDays(1);
                    numberofWorkDays++;
                }
                else
                {
                    futureDate = futureDate.AddDays(1);
                }
            }
            while (//futureDate.DayOfWeek == DayOfWeek.Saturday
                    futureDate.DayOfWeek == DayOfWeek.Sunday
                    || (holidays != null && holidays.Contains(futureDate)))
            {
                futureDate = futureDate.AddDays(1);
            }
            return futureDate;
        }

        #endregion Add Business Days

        #region ReadXMLByTagName
        public static string ReadXMLByTagName(string XMLFileWithPath, string TagName, int node = 0, bool readFirstLine = true)
        {
            string sValue = "";

            if (File.Exists(XMLFileWithPath))
            {
                StreamReader reader = new StreamReader(XMLFileWithPath);
                byte[] encodedString = null;

                if (readFirstLine)
                    encodedString = Encoding.UTF8.GetBytes(reader.ReadToEnd());
                else
                {
                    reader.ReadLine(); //Skip the first line
                    encodedString = Encoding.UTF8.GetBytes(reader.ReadToEnd());
                }

                MemoryStream ms = new MemoryStream(encodedString);
                ms.Flush();
                ms.Position = 0;
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(ms);
                sValue = xmlDoc.GetElementsByTagName(TagName)[node].InnerText.Trim();
                ms.Close();
            }

            return sValue;
        }
        #endregion

        #region ReadXMLFromURLByTagName
        public static string ReadXMLFromURLByTagName(string URL, string TagName, int node = 0, bool readFirstLine = true)
        {
            string sValue = "";
            XmlDocument xmlDoc = new XmlDocument();

            xmlDoc.Load(URL);
            sValue = xmlDoc.GetElementsByTagName(TagName)[node].InnerText.Trim();

            return sValue;
        }
        #endregion

        #region DirectoryCopy
        ///<summary>
        ///<para>Copies source folder sourceDirName to destination folder destDirName including contents.</para>
        ///<para>Example: General.DirectoryCopy("C:\\Reports","D:\\Reports",true);</para>
        ///</summary>
        public static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = dir.GetDirectories();

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            // If the destination directory doesn't exist, create it. 
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, true);
            }

            // If copying subdirectories, copy them and their contents to new location. 
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
            }
        }
        #endregion

        #region ReadXMLAppSettings
        private static string ReadXMLAppSettings(string ConfigPath, string option, string key)
        {
            string sValue = "";
            XmlDocument xDoc = new XmlDocument();
            if (File.Exists(ConfigPath))
            {
                xDoc.Load(ConfigPath);
                try { sValue = xDoc.DocumentElement.SelectSingleNode(option + "/" + key).InnerText.Trim(); }
                catch { sValue = "KEY_NOT_FOUND"; }
            }
            return sValue;
        }
        #endregion

        //Move to AutoConfig class

        //#region GetRunOption
        /////<summary>
        /////<para>Gets value of key under the category "option" under Environment specified from the AutoConfig.xml.</para>
        /////<para>Example: string UserId = General.GetRunOption("User_Name");</para>
        /////</summary>
        //public static string GetRunOption(string key)
        //{
        //    string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
        //    string sValue = ReadXMLConfiguration(ConfigPath, "Option", key);
        //    return sValue;
        //}
        //#endregion

        #region DataSave
        ///<summary>
        ///<para>Creates a node inKey (Inobject if inKey is blank) with value inValue in Localdata.xml file under REPORTSDIR folder mentioned in AutoConfig.xml file</para>
        ///<para>Example: General.DataSave("","Key1","Key1Value");</para>
        ///</summary>
        public static void DataSave(string Inobject, string inkey, string inValue)
        {
            string sKey = inkey;
            bool IskeyFound = false;
            if (inkey.Equals(""))
                sKey = Inobject;

            value = inValue;

            string localFilePath = Directory.GetParent(Reports.RUNRESULTDIR).ToString() + "\\" + Support.TESTENVIRONMENT + "_LocalData.xml";
            if (File.Exists(localFilePath))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(localFilePath);

                XmlNode xNode = doc.GetElementsByTagName("datastore")[0];

                XmlNodeList AllParentObjs = doc.GetElementsByTagName("data");

                for (int j = 0; j < AllParentObjs.Count; j++)
                {
                    if (AllParentObjs[j].ChildNodes[0].InnerText.Equals(sKey))
                    {
                        AllParentObjs[j].ChildNodes[1].InnerText = inValue;
                        IskeyFound = true;
                    }
                }
                if (!IskeyFound)
                {
                    XmlNode dataNode = doc.CreateElement("data");
                    xNode.AppendChild(dataNode);

                    XmlNode keyNode = doc.CreateElement("key");
                    keyNode.InnerText = sKey;
                    dataNode.AppendChild(keyNode);

                    XmlNode valueNode = doc.CreateElement("value");
                    valueNode.InnerText = inValue;
                    dataNode.AppendChild(valueNode);

                }
                doc.Save(localFilePath);
            }
            else
            {
                XmlDocument doc = new XmlDocument();
                FileStream rfile = new FileStream(localFilePath, FileMode.Create);
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(docNode);
                XmlNode datastoreNode = doc.CreateElement("datastore");
                doc.AppendChild(datastoreNode);

                XmlNode dataNode = doc.CreateElement("data");
                datastoreNode.AppendChild(dataNode);

                XmlNode keyNode = doc.CreateElement("key");
                keyNode.InnerText = sKey;
                dataNode.AppendChild(keyNode);

                XmlNode valueNode = doc.CreateElement("value");
                valueNode.InnerText = inValue;
                dataNode.AppendChild(valueNode);

                doc.Save(rfile);
                rfile.Close();
            }
            value = inValue;
            Reports.UpdateDebugLog("Save data", "", "Save", sKey, value, "", Reports.Result(true), "");
        }
        #endregion

        #region DataSave
        ///<summary>
        ///<para>Creates a node inKey (Inobject if inKey is blank) with value inValue in Localdata.xml file under REPORTSDIR folder mentioned in AutoConfig.xml file</para>
        ///<para>Example: General.DataSave("","Key1","Key1Value");</para>
        ///</summary>
        public static void DataSave(string inkey, string inValue)
        {
            string sKey = inkey;
            bool IskeyFound = false;

            value = inValue;

            string localFilePath = Directory.GetParent(Reports.RUNRESULTDIR).ToString() + "\\" + Support.TESTENVIRONMENT + "_LocalData.xml";
            if (File.Exists(localFilePath))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(localFilePath);

                XmlNode xNode = doc.GetElementsByTagName("datastore")[0];

                XmlNodeList AllParentObjs = doc.GetElementsByTagName("data");

                for (int j = 0; j < AllParentObjs.Count; j++)
                {
                    if (AllParentObjs[j].ChildNodes[0].InnerText.Equals(sKey))
                    {
                        AllParentObjs[j].ChildNodes[1].InnerText = inValue;
                        IskeyFound = true;
                    }
                }
                if (!IskeyFound)
                {
                    XmlNode dataNode = doc.CreateElement("data");
                    xNode.AppendChild(dataNode);

                    XmlNode keyNode = doc.CreateElement("key");
                    keyNode.InnerText = sKey;
                    dataNode.AppendChild(keyNode);

                    XmlNode valueNode = doc.CreateElement("value");
                    valueNode.InnerText = inValue;
                    dataNode.AppendChild(valueNode);

                }
                doc.Save(localFilePath);

            }
            else
            {
                XmlDocument doc = new XmlDocument();
                FileStream rfile = new FileStream(localFilePath, FileMode.Create);
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(docNode);
                XmlNode datastoreNode = doc.CreateElement("datastore");
                doc.AppendChild(datastoreNode);

                XmlNode dataNode = doc.CreateElement("data");
                datastoreNode.AppendChild(dataNode);

                XmlNode keyNode = doc.CreateElement("key");
                keyNode.InnerText = sKey;
                dataNode.AppendChild(keyNode);

                XmlNode valueNode = doc.CreateElement("value");
                valueNode.InnerText = inValue;
                dataNode.AppendChild(valueNode);

                doc.Save(rfile);
                rfile.Close();
            }
            value = inValue;
            Reports.UpdateDebugLog("Save data", "", "Save", sKey, value, "", Reports.Result(true), "");
        }
        #endregion

        #region DataLoad
        ///<summary>
        ///<para>Assigns General.data with value of key (Inobject if Key is blank) from Localdata.xml file under REPORTSDIR folder mentioned in AutoConfig.xml file</para>
        ///<para>Example: General.DataLoad("","Key1");</para>
        ///</summary>
        public static void DataLoad(string Inobject, string key)
        {
            string sKey = key;
            bool IskeyFound = false;
            if (key.Equals(""))
                sKey = Inobject;

            string localFilePath = Directory.GetParent(Reports.RUNRESULTDIR).ToString() + "\\" + Support.TESTENVIRONMENT + "_LocalData.xml";
            if (File.Exists(localFilePath))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(localFilePath);

                XmlNode xNode = doc.GetElementsByTagName("datastore")[0];

                XmlNodeList AllParentObjs = doc.GetElementsByTagName("data");

                for (int j = 0; j < AllParentObjs.Count; j++)
                {
                    if (AllParentObjs[j].ChildNodes[0].InnerText.Equals(sKey))
                    {
                        data = AllParentObjs[j].ChildNodes[1].InnerText;
                        IskeyFound = true;
                    }
                }
                if (!IskeyFound)
                    data = "Key " + sKey + " doesn't Exist";
            }
            else
            {
                data = Support.TESTENVIRONMENT + "_LocalData.xml FileNotFound";
            }
            Reports.UpdateDebugLog("Load data", "", "Load", sKey, data, "", Reports.Result(true), "");
        }
        #endregion

        #region DataLoad
        ///<summary>
        ///<para>Assigns General.data with value of key (Inobject if Key is blank) from Localdata.xml file under REPORTSDIR folder mentioned in AutoConfig.xml file</para>
        ///<para>Example: General.DataLoad("","Key1");</para>
        ///</summary>
        public static void DataLoad(string key)
        {
            string sKey = key;
            bool IskeyFound = false;

            string localFilePath = Directory.GetParent(Reports.RUNRESULTDIR).ToString() + "\\" + Support.TESTENVIRONMENT + "_LocalData.xml";
            if (File.Exists(localFilePath))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(localFilePath);

                XmlNode xNode = doc.GetElementsByTagName("datastore")[0];

                XmlNodeList AllParentObjs = doc.GetElementsByTagName("data");

                for (int j = 0; j < AllParentObjs.Count; j++)
                {
                    if (AllParentObjs[j].ChildNodes[0].InnerText.Equals(sKey))
                    {
                        data = AllParentObjs[j].ChildNodes[1].InnerText;
                        IskeyFound = true;
                    }
                }
                if (!IskeyFound)
                    data = "Key " + sKey + " doesn't Exist";
            }
            else
            {
                data = Support.TESTENVIRONMENT + "_LocalData.xml FileNotFound";
            }
            Reports.UpdateDebugLog("Load data", "", "Load", sKey, data, "", Reports.Result(true), "");
        }
        #endregion

        #region Generate two dimensional array of Fields & it's Values.
        private static string[,] Generate_FieldValue_List(string Operation, string vallist, out int fieldCount)
        {
            string[,] fieldValues = new string[2, 50];
            string[] splitArr2 = new string[] { };
            int i = 0;
            fieldCount = 0;
            int fieldValCount = 0;

            string[] splitArr1 = vallist.Split('~');

            fieldValCount = splitArr1.Length;
            if (fieldValCount != 0)
            {
                for (i = 0; i < fieldValCount; i++)
                {
                    splitArr2 = splitArr1.GetValue(i).ToString().Split('=');
                    if (splitArr2.Length > 1)
                    {
                        fieldValues[0, i] = splitArr2.GetValue(0).ToString();
                        fieldValues[1, i] = splitArr2.GetValue(1).ToString();
                    }
                    else
                    {
                        fieldValues[0, i] = splitArr2.GetValue(0).ToString();
                        fieldValues[1, i] = "";
                    }
                }
                fieldCount = i;
            }

            return fieldValues;
        }
        #endregion

        #region Get Property Collection for the specified object from XML Object Repository.
        ///<summary>
        ///<para>Do not Use. Used Internally. Gets  Properties of the control specified from the Object Map.</para>
        ///</summary>
        public static string GetORPropertyValues(Stream ObjStream, string sObjName, bool IsParent)
        {
            XmlDocument xdoc = new XmlDocument();
            MIC_CLASS = "";
            string sProperties = "NO_PROPS";

            try
            {
                xdoc.Load(ObjStream);

                XmlElement targetElement = null;

                if (IsParent)
                {
                    targetElement = (XmlElement)xdoc.SelectSingleNode("/ObjectMap/Parent[@LogicalName='" + OBJ_PARENT + "']");
                    OBJ_PARENT_ELEMENT = targetElement;
                }
                else
                {
                    targetElement = (XmlElement)OBJ_PARENT_ELEMENT.GetElementsByTagName(sObjName)[0];
                }


                MIC_CLASS = targetElement.Attributes["class"].Value;
                Reports.obj_class = MIC_CLASS;
                sProperties = targetElement.Attributes["properties"].Value;
            }
            catch (Exception e)
            {
                GeneralMessage = "Please check XML file: Exception Occured is " + e.Message;
            }
            return sProperties;
        }
        #endregion

        #region Generates Random string based on the length
        private static string RandomString(double dNum, int size, bool lcase)
        {
            StringBuilder builder = new StringBuilder();
            //Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * dNum + 65)));
                builder.Append(ch);
            }
            if (lcase)
                return builder.ToString().ToLower();

            return builder.ToString();
        }
        #endregion

        #region Generats Random number with given length
        ///<summary>
        ///<para>Gets random number within the limit specified.</para>
        ///<para>Example: int rNumber = General.RandomNumber(100);</para>
        ///</summary>
        public static int RandomNumber(int maxValue)
        {
            Random random = new Random();
            int num = random.Next(maxValue);
            return num;
        }

        public static int RandomNumber(int minValue, int maxValue)
        {
            Random random = new Random();
            int num = random.Next(minValue, maxValue);
            return num;
        }
        #endregion

        #region Generates Random String based on the character type passed, example RandomString("aANZ")
        ///<summary>
        ///<para>Gets random string based on the data specified. a,A,N,Z stands for lower case alphabet, upper case alphabet</para>
        ///<para>Number & Alpha Numberic respectively.</para>
        ///<para>Example: string rstring = General.RandomString("aANZ"); this might return string "bJ9a"</para>
        ///</summary>
        public static string RandomString(string data)
        {
            Random random = new Random();
            StringBuilder builder = new StringBuilder();
            string randomText;
            int cnt = data.Length;
            for (int i = 0; i < cnt; i++)
            {
                if (data.Substring(i, 1) == "a")
                    builder.Append(RandomString(random.NextDouble(), 1, true));
                else if (data.Substring(i, 1) == "A")
                    builder.Append(RandomString(random.NextDouble(), 1, false));
                else if (data.Substring(i, 1) == "N")
                    builder.Append(random.Next(10));
                else if (data.Substring(i, 1) == "Z")
                {
                    randomText = System.Guid.NewGuid().ToString().Replace("-", string.Empty);
                    builder.Append(randomText.Substring(1, 1));
                }
            }
            return builder.ToString();
        }
        #endregion

        #region Save PDF file to given path
        ///<summary>
        ///<para>Saves PDF file to the path specified. Make sure PDF file is Open before this function.</para>
        ///<para>Example: bool IsPDFSaveSuccess = General.SavePDF("C:\\Reports\\PDF");</para>
        ///</summary>
        public static bool SavePDF(string ARFileName)
        {
            GeneralMessage = "";
            bool iResult = false;
            try
            {
                WinWindow ARWindow = new WinWindow();
                ARWindow.SearchProperties[WinWindow.PropertyNames.ClassName] = "AcrobatSDIWindow";

                WinTitleBar ARTitleBar = new WinTitleBar(ARWindow);

                WinWindow ARAVPageView = new WinWindow(ARWindow);
                ARAVPageView.SearchProperties[WinWindow.PropertyNames.Name] = "AVPageView";
                ARAVPageView.SearchProperties[WinWindow.PropertyNames.ClassName] = "AVL_AVView";

                WinWindow ARSaveAs = new WinWindow();
                ARSaveAs.SearchProperties[WinWindow.PropertyNames.Name] = "Save As";
                ARSaveAs.SearchProperties[WinWindow.PropertyNames.ClassName] = "#32770";
                ARSaveAs.WindowTitles.Add("Save As");

                WinWindow ARItemWindow = new WinWindow(ARSaveAs);
                ARItemWindow.SearchProperties[WinWindow.PropertyNames.ControlId] = "1148";
                ARItemWindow.SearchProperties[WinWindow.PropertyNames.Instance] = "2";
                ARItemWindow.WindowTitles.Add("Save As");

                WinComboBox ARFileNameCombo = new WinComboBox(ARItemWindow);
                ARFileNameCombo.SearchProperties[WinComboBox.PropertyNames.Name] = "File name:";
                ARFileNameCombo.WindowTitles.Add("Save As");

                WinWindow ARSaveWindow = new WinWindow(ARSaveAs);
                ARSaveWindow.SearchProperties[WinWindow.PropertyNames.ControlId] = "1";
                ARSaveWindow.SearchProperties[WinWindow.PropertyNames.Instance] = "2";
                ARSaveWindow.WindowTitles.Add("Save As");

                WinButton ARSaveButton = new WinButton(ARSaveWindow);
                ARSaveButton.SearchProperties[WinButton.PropertyNames.Name] = "Save";
                ARSaveButton.WindowTitles.Add("Save As");

                WinButton ARCloseButton = new WinButton(ARTitleBar);
                ARCloseButton.SearchProperties[WinButton.PropertyNames.Name] = "Close";

                // on some of machines, browser is used to open PDF doc
                BrowserWindow PDFWindow = new BrowserWindow();
                PDFWindow.SearchProperties["ClassName"] = "IEFrame";
                PDFWindow.SearchProperties.Add("Name", @"Documents/Print", PropertyExpressionOperator.Contains);

                Support.MessageHandler();   // handle any Adobe Reader related popup.

                if (PDFWindow.Exists) // Handle when browser is used to open PDF doc
                {
                    Keyboard.SendKeys(PDFWindow, "S", (ModifierKeys.Control | ModifierKeys.Shift));
                    Playback.Wait(1000);
                    ARFileNameCombo.EditableItem = ARFileName;
                    Mouse.Click(ARSaveButton);
                    PDFWindow.Close();
                    iResult = true;

                }
                else if (ARTitleBar.Exists)
                {
                    // Click 'Document_6343886652029576411[1].pdf - Adobe Reader' title bar
                    Mouse.Click(ARTitleBar);

                    // Type 'Control, Shift + S' in 'AVPageView' window
                    Keyboard.SendKeys(ARAVPageView, "S", (ModifierKeys.Control | ModifierKeys.Shift));

                    // Select 'c:\QuickFileEntry2.pdf' in 'File name:' combo box
                    ARFileNameCombo.EditableItem = ARFileName;

                    // Click '&Save' button
                    Mouse.Click(ARSaveButton);

                    // Click 'Close' button
                    Mouse.Click(ARCloseButton);

                    iResult = true;
                }

                return iResult;

            }
            catch (Exception e)
            {
                // try to close PDF window using Alt+F4
                if (e.Message == "Unable to get reference to the document.") //unable to close the PDF window
                {
                    BrowserWindow PDFWindow = new BrowserWindow();
                    PDFWindow.SearchProperties["ClassName"] = "IEFrame";
                    PDFWindow.SearchProperties.Add("Name", ".pdf", PropertyExpressionOperator.Contains);
                    Keyboard.SendKeys(PDFWindow, "%{F4}");
                    return true;
                }
                else
                {
                    GeneralMessage = GeneralMessage + e.Message;
                    iResult = false;
                    //ADD_INFO = "In savepdf: " + e.Message;
                    return iResult;
                }
            }
        }
        #endregion

        #region Keyboard Sendkeys Operations.
        ///<summary>
        ///<para>Sendkeys mentioned using Keyboard.</para>
        ///<para>Example: General.SendKeys("abcd");</para>
        ///</summary>
        public static void SendKeys(string stext)
        {
            Keyboard.SendKeys(stext);
        }

        #region Keyboard Sendkeys Operations.
        ///<summary>
        ///<para>Sendkeys mentioned using Keyboard.</para>
        ///<para>Example: SendKeys("abcd",ModifierKeys.Control);</para>
        ///</summary>
        public static void SendKeys(string sText, ModifierKeys Mkey)
        {
            Keyboard.SendKeys(sText, Mkey);
        }
        #endregion

        public static void SendKeys(UITestControl sControl, string sText, ModifierKeys Mkey)
        {
            Keyboard.SendKeys(sControl, sText, Mkey);
        }
        #endregion

        #region Performs Hot keys action for multiple selection
        ///<summary>
        ///<para>Sets the Modifier Keys. This takes "control","alt","shift" as inputs. assigns Modifier key to parameter General.MODIFIER_KEY</para>
        ///<para>Example: General.Additionalkeys("control");</para>
        ///</summary>
        public static void Additionalkeys(string MKey)
        {
            try
            {
                if (MKey.ToLower().Equals("control"))
                    MODIFIER_KEY = ModifierKeys.Control;
                else if (MKey.ToLower().Equals("alt"))
                    MODIFIER_KEY = ModifierKeys.Control;
                else if (MKey.ToLower().Equals("shift"))
                    MODIFIER_KEY = ModifierKeys.Shift;
                else
                    MODIFIER_KEY = ModifierKeys.None;

            }
            catch { };

        }
        #endregion

        #region Message Handler
        //Last Modified on : 17th Nov 2014 11:20 PM
        //Last Modified By : Yusuf
        //Purpose : To handle any unexpected pop-up with "Yes" and "No" buttons. 
        //Scope Identification : FMUC0023_REG0006, Screen : Change Owning Office / Remove Service Type
        ///<summary>
        ///<para>Clicks OK button the Message box displayed.</para>
        ///<para>Example: General.MessageHandler;</para>
        ///</summary>
        public static void MessageHandler()
        {
            UITestControl sMessageBoxWin = new UITestControl();
            sMessageBoxWin.TechnologyName = "MSAA";
            sMessageBoxWin.SearchProperties["ControlType"] = "Window";
            sMessageBoxWin.SearchProperties["ClassName"] = "#32770";

            //if (sMessageBoxWin.TryFind() && sMessageBoxWin.FriendlyName == "VBScript: Password Expiry Confirmation")
            //{
            //    WinButton btnNo = new WinButton(sMessageBoxWin);
            //    btnNo.SearchProperties["Name"] = "No";
            //    Mouse.Click(btnNo);
            //    return;
            //}

            //WinButton btnOpen = new WinButton(sMessageBoxWin);
            //btnOpen.SearchProperties["Name"] = "Open";

            WinButton btnOK = new WinButton(sMessageBoxWin);
            btnOK.SearchProperties["Name"] = "OK";

            WinButton btnLeavethisPage = new WinButton(sMessageBoxWin);
            btnLeavethisPage.SearchProperties["Name"] = "Leave this page";

            WinButton confYes = new WinButton(sMessageBoxWin);
            confYes.SearchProperties["Name"] = "Yes";

            bool IsOKClick = false;
            bool IsDlgClose = false;

            int iTimeout = Playback.PlaybackSettings.SearchTimeout;
            Playback.PlaybackSettings.SearchTimeout = 2000;

            try
            {
                //if (btnOpen.Exists)
                //{
                //    Mouse.Click(btnOpen);
                //    return;
                //}

                if (btnOK.Exists)
                {
                    //Reports.CaptureImage();
                    Reports.StatusUpdate("MessageHandler:OK", true);
                    Mouse.Click(btnOK);
                    IsOKClick = true;
                }

                //if (confYes.Exists)
                //{
                //    //Reports.CaptureImage();
                //    Reports.StatusUpdate("MessageHandler:Yes", true);
                //    Mouse.Click(confYes);
                //    IsOKClick = true;
                //}

                if (btnLeavethisPage.Exists)
                {
                    //Reports.CaptureImage();
                    Reports.StatusUpdate("MessageHandler:LeavePage", true);
                    Mouse.Click(btnLeavethisPage);
                    IsOKClick = true;
                }

                if (IsOKClick && (btnOK.Exists || btnLeavethisPage.Exists))
                {
                    //Reports.CaptureImage();
                    Reports.StatusUpdate("MessageHandler:OK:Yes:LeavePage", true);
                    if (btnOK.Exists)
                    {
                        Mouse.Click(btnOK);
                    }

                    //if (confYes.Exists)
                    //{
                    //    Mouse.Click(confYes);
                    //}

                    if (btnLeavethisPage.Exists)
                    {
                        Mouse.Click(btnLeavethisPage);
                    }
                }
            }
            catch { }

            if (bCloseDlg)
            {
                sMessageBoxWin.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
                WinTitleBar tBar = new WinTitleBar(sMessageBoxWin);
                WinButton sCloseBtn = new WinButton(tBar);
                sCloseBtn.SearchProperties["Name"] = "Close";

                try
                {
                    if (sCloseBtn.Exists)
                    {
                        //Reports.CaptureImage();
                        Reports.StatusUpdate("MessageHandler:Close1", true);
                        Mouse.Click(sCloseBtn);
                        IsDlgClose = true;
                    }
                    if (IsDlgClose && sCloseBtn.Exists)
                    {
                        //Reports.CaptureImage();
                        Reports.StatusUpdate("MessageHandler:Close2", true);
                        Mouse.Click(sCloseBtn);
                    }
                }
                catch { }
            }
            bCloseDlg = true;

            Playback.PlaybackSettings.SearchTimeout = iTimeout;
            //Reports.StatusUpdate("Message Handler", true);
        }
        #endregion

        #region Message Handler 1 - dialogclose
        ///<summary>
        ///<para>Clicks OK button the Message box displayed. Then if dialogclose is false then closes any dialog displayed.</para>
        ///<para>Example: General.MessageHandler(false);</para>
        ///</summary>
        public static void MessageHandler(bool dialogclose)
        {
            UITestControl sMessageBoxWin = new UITestControl();
            sMessageBoxWin.TechnologyName = "MSAA";
            sMessageBoxWin.SearchProperties["ControlType"] = "Window";
            sMessageBoxWin.SearchProperties["ClassName"] = "#32770";

            WinButton btnOK = new WinButton(sMessageBoxWin);
            btnOK.SearchProperties["Name"] = "OK";

            bool IsOKClick = false;
            bool IsDlgClose = false;

            int iTimeout = Playback.PlaybackSettings.SearchTimeout;
            Playback.PlaybackSettings.SearchTimeout = 2000;

            try
            {
                if (btnOK.Exists)
                {
                    //Reports.CaptureImage();
                    Reports.StatusUpdate("MessageHandler:OK1", true);
                    Mouse.Click(btnOK);
                    IsOKClick = true;
                }
                if (IsOKClick && btnOK.Exists)
                {
                    //Reports.CaptureImage();
                    Reports.StatusUpdate("MessageHandler:OK2", true);
                    Mouse.Click(btnOK);
                }
            }
            catch { }

            if (!dialogclose)
            {

                sMessageBoxWin.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
                WinTitleBar tBar = new WinTitleBar(sMessageBoxWin);
                WinButton sCloseBtn = new WinButton(tBar);
                sCloseBtn.SearchProperties["Name"] = "Close";

                try
                {
                    if (sCloseBtn.Exists)
                    {
                        //Reports.CaptureImage();
                        Reports.StatusUpdate("MessageHandler:Dialog1", true);
                        Mouse.Click(sCloseBtn);
                        IsDlgClose = true;
                    }
                    if (IsDlgClose && sCloseBtn.Exists)
                    {
                        //Reports.CaptureImage();
                        Reports.StatusUpdate("MessageHandler:Dialog2", true);
                        Mouse.Click(sCloseBtn);
                    }
                }
                catch { }
            }

            Playback.PlaybackSettings.SearchTimeout = iTimeout;
        }
        #endregion

        #region Java script error Handler
        public static void scripterrorhandler()
        {
            try
            {
                BrowserWindow sBr = new BrowserWindow();
                sBr.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";

                Microsoft.VisualStudio.TestTools.UITesting.HtmlControls.HtmlDocument sDoc = new Microsoft.VisualStudio.TestTools.UITesting.HtmlControls.HtmlDocument(sBr);
                sDoc.SearchProperties["Title"] = "Script Error";
                sDoc.SearchProperties["TagName"] = "BODY";

                HtmlButton sButton = new HtmlButton(sDoc);
                sButton.SearchProperties["Id"] = "btnYes";
                sButton.SearchProperties["TagName"] = "BUTTON";

                //Reports.CaptureImage();
                MessageHandler(true);
                Mouse.Click(sButton);
                Reports.StatusUpdate("Script Error Handled", true);
                Playback.Wait(5000);
            }
            catch { }
        }
        #endregion

        #region Close All IE Process
        ///<summary>
        ///<para>Closes all Processes starting with processname</para>
        ///<para>Example: General.CloseAllProcessStartingWith("iexplore");</para>
        ///</summary>
        public static void CloseAllProcessStartingWith(string processname)
        {
            foreach (Process clsProcess in Process.GetProcesses())
            {
                if (clsProcess.ProcessName.ToLower().StartsWith(processname.ToLower()))
                {
                    clsProcess.StartInfo.UseShellExecute = true;
                    clsProcess.StartInfo.Verb = "runas";
                    clsProcess.Kill();
                }
            }
        }
        #endregion

        #region Find & Replace in file
        ///<summary>
        ///<para>Find and Replace text tobereplaced passed with replacewith, Modifies OrgFile and Saves it as TarFile</para>
        ///<para>Example: General.FindReplaceinFile("C:\AutoConfig.xml","C:\Config.xml","Environment","EVAL01");</para>
        ///</summary>
        public static bool FindReplaceinFile(string OrgFile, string TarFile, string tobereplaced, string replacewith)
        {
            try
            {
                //get a StreamReader for reading the file
                StreamReader reader = new StreamReader(OrgFile);

                //read the entire file at once
                string contents = reader.ReadToEnd();

                //close up and dispose
                reader.Close();
                reader.Dispose();

                contents = contents.Replace(tobereplaced, replacewith);

                //get a StreamWriter for writing the new text to the file
                StreamWriter writer = new StreamWriter(TarFile);

                //write the contents
                writer.Write(contents);

                //close up and dispose
                writer.Close();
                writer.Dispose();

                //return successful
                return true;
            }
            catch { }
            return false;
        }
        #endregion

        #region Get Object Map Stream
        ///<summary>
        ///<para>Ignore this. Used Internally. Get Stream of file from an assembly.</para>
        ///</summary>
        public static Stream GetObjectMapStream(string binary, string file)
        {
            string fileContents = string.Empty;
            Stream stream = null;
            OBJECT_MAP = file;
            try
            {
                Assembly current = Assembly.LoadFrom(binary + ".dll");
                try
                {
                    stream = current.GetManifestResourceStream(binary + ".ObjectMaps." + file + ".XML");
                }
                catch
                {
                    stream = current.GetManifestResourceStream(binary + ".ObjectMaps." + file + ".xml");
                }
            }
            catch
            {
                stream = null;
                GeneralMessage = "";
            }
            return stream;
        }
        #endregion

        #region Get Embedded Report file
        ///<summary>
        ///<para>Ignore this. Used Internally. Gets an embedded file "file" from assembly and saves it in the "filepath" specified</para>
        ///</summary>
        public static bool GetEmbeddedFile(string binary, string file, string filePath)
        {
            bool iResult = false;
            string fileContents = string.Empty;
            try
            {
                Assembly current = Assembly.LoadFrom(binary + ".dll");
                using (Stream stream = current.GetManifestResourceStream(binary + "." + file))
                {
                    using (StreamReader streamReader = new StreamReader(stream))
                    {
                        fileContents = streamReader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                string sMsg = ex.Message;
                iResult = false;
                return iResult;
            }

            using (StreamWriter sw = new StreamWriter(filePath))
            {
                sw.Write(fileContents);
                sw.Close();
                iResult = true;
            }
            return iResult;
        }
        #endregion

        #region Get Embedded Images
        ///<summary>
        ///<para>Ignore this. Used Internally. Gets an embedded file "file" from assembly and saves it in the "filepath" specified</para>
        ///</summary>
        public static bool GetEmbeddedImages(string binary, string file, string filePath)
        {
            bool iResult = false;
            string fileContents = string.Empty;
            try
            {
                Assembly current = Assembly.LoadFrom(binary + ".dll");
                Stream stream = current.GetManifestResourceStream(binary + "." + file);
                System.Drawing.Image tmpImage = Image.FromStream(stream);
                tmpImage.Save(filePath);
                Image.FromStream(stream);
                iResult = true;
            }
            catch (Exception ex)
            {
                string sMsg = ex.Message;
                iResult = false;
                return iResult;
            }
            return iResult;
        }
        #endregion

        #region Execute Command
        /// <summary>
        /// Execute a command using the command windows
        /// </summary>
        /// <param name="command">command argument</param>
        /// <returns>boolean</returns>
        public static bool ExecuteCommand(string command)
        {
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                startInfo.FileName = "cmd.exe";
                startInfo.Arguments = command;
                process.StartInfo = startInfo;
                process.Start();
            }
            catch { return false; }

            return true;
        }
        #endregion

        #region Delete Cache, Cookies etc
        ///<summary>
        ///<para>Deletes Cache and Cookies of IE browser.</para>
        ///<para>Example: DeleteCacheCookies();</para>
        ///</summary>
        public static void DeleteCacheCookies()
        {
            try
            {
                BrowserWindow.ClearCache();
                BrowserWindow.ClearCookies();
            }
            catch { }
        }
        #endregion

        #region Handle the IE Download Message
        ///<summary>
        ///<para>Handles the Download message prompted by IE</para>
        ///<para>Example: downLoadMsgHandler("open");</para>
        ///</summary>
        public static void downLoadMsgHandler(string action)
        {
            try
            {
                BrowserWindow IEBrowser = new BrowserWindow();
                IEBrowser.SearchProperties["ClassName"] = "IEFrame";

                WinToolBar wToolBar = new WinToolBar(IEBrowser);
                wToolBar.SearchProperties[WinToolBar.PropertyNames.Name] = "Notification";

                if (action.ToUpper() == "SAVE")
                {
                    WinSplitButton wSplitButton = new WinSplitButton(wToolBar);
                    wSplitButton.SearchProperties["Name"] = action;
                    Mouse.Click(wSplitButton);

                    Playback.Wait(5000);
                    WinButton wButton = new WinButton(wToolBar);
                    wButton.SearchProperties["Name"] = "Close";
                    Mouse.Click(wButton);

                }
                else
                {
                    WinButton wButton = new WinButton(wToolBar);
                    wButton.SearchProperties["Name"] = action;
                    Mouse.Click(wButton);
                }
            }
            catch { }
        }
        #endregion

        #region Create Dummy Control
        public static UITestControl DummyControl()
        {
            UITestControl sControl = new UITestControl();
            return sControl;
        }

        #endregion




        /// <summary>
        /// Send Email
        /// </summary>
        /// <param name="mail">Prepared mail message: To, CC, Subject, From, Body, Attachments</param>
        public static void SendEmail(string to, string cc, string subject, string from, string body, List<string> attachments)
        {
            //TODO: put this in config
            string smtpServer = "FAHQSNA09VXHT04.corp.firstam.com";

            try
            {
                if (String.IsNullOrEmpty(from))
                    from = "QA_Automation@FAST";

                MailMessage email = new MailMessage();
                email.From = new MailAddress(from);
                email.Subject = subject;
                email.Body = body;
                email.IsBodyHtml = !String.IsNullOrEmpty(body) && body.ToLower().Contains("<html");

                string[] recipients = to.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string recipient in recipients)
                    email.To.Add(recipient);

                if (!String.IsNullOrEmpty(cc))
                    email.CC.Add(cc.Replace(";", ","));

                if (attachments != null)
                {
                    foreach (string attachemt in attachments)
                        email.Attachments.Add(new Attachment(attachemt));
                }

                email.IsBodyHtml = true;
                SmtpClient client = new SmtpClient(smtpServer);
                client.Send(email);

            }
            catch (Exception ex)
            {
                throw new Exception("ERROR sending Email", ex);
            }
        }

        /// <summary>
        ///    Compares two XML files. 
        ///    If the resultFile parameter is not null it will contain the list of changes 
        ///    between the two XML files.
        /// </summary>
        /// <param name="xmlFile1">The original xml document filename</param>
        /// <param name="xmlFile2">The changed xml document filename.</param>
        /// <param name="resultFile">result file name (html) for returning the list of changes.</param>
        /// <param name="options">XmlCompare options.</param>
        /// <returns>True, if the documents are identical. Otherwise returns false.</returns>
        public static bool XmlCompare(string xmlFile1, string xmlFile2, string resultFile, XmlComareOptions options = XmlComareOptions.None)
        {
            bool result = false;

            try
            {
                MemoryStream diffgram = new MemoryStream();
                XmlTextWriter diffgramWriter = new XmlTextWriter(new StreamWriter(diffgram, Encoding.Unicode));
                XmlDiffAlgorithm algorithm = XmlDiffAlgorithm.Auto;

                // create xmlDiff object and do the comparing
                XmlDiff xmlDiff = new XmlDiff((XmlDiffOptions)options);
                xmlDiff.Algorithm = algorithm;
                result = xmlDiff.Compare(xmlFile1, xmlFile2, false, diffgramWriter);
                Reports.StatusUpdate("XmlCompare", result, "", "", "", "", "", "Files are " + (result ? "identical." : "different."));

                // create  HTML report file
                TextWriter resultHtml = new StreamWriter(new FileStream(resultFile, FileMode.Create, FileAccess.Write));
                resultHtml.WriteLine("<html><head>");
                resultHtml.WriteLine("<style TYPE='text/css' MEDIA='screen'>");
                resultHtml.Write("<!-- td { font-family: Courier New; font-size:14; } th { font-family: Arial; } p { font-family: Arial; } -->");
                resultHtml.WriteLine("</style></head>");
                resultHtml.WriteLine("<body><h3 style='font-family:Arial'>XmlDiff view</h3><table border='0'><tr><td><table border='0'>");
                resultHtml.WriteLine("<tr><th>" + xmlFile1 + "</th><th>" + xmlFile2 + "</th></tr><tr><td colspan=2><hr size=1></td></tr>");
                if (result)
                    resultHtml.WriteLine("<tr><td colspan='2' align='middle'>Files are identical.</td></tr>");
                else
                    resultHtml.WriteLine("<tr><td colspan='2' align='middle'>Files are different.</td></tr>");

                diffgram.Seek(0, SeekOrigin.Begin);

                XmlDiffView xmlDiffView = new Microsoft.XmlDiffPatch.XmlDiffView();
                XmlTextReader sourceReader;
                sourceReader = new XmlTextReader(xmlFile1);

                sourceReader.XmlResolver = null;
                xmlDiffView.Load(sourceReader, new XmlTextReader(diffgram));
                xmlDiffView.GetHtml(resultHtml);
                resultHtml.WriteLine("</table></table></body></html>");
                resultHtml.Close();

                Reports.StatusUpdate("XmlCompare", true, "", "", "", "", "", resultFile + " saved successfully.");
            }
            catch (Exception e)
            {
                Reports.StatusUpdate("XmlCompare", false, "", "", "", "", "", "Exception occurs. " + e.Message);
            }

            return result;
        }

        public static byte[] GetHashKey(string hashKey)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            string salt = "I am a nice little salt";
            byte[] saltBytes = encoder.GetBytes(salt);
            Rfc2898DeriveBytes rfc = new Rfc2898DeriveBytes(hashKey, saltBytes);
            return rfc.GetBytes(16);
        }
        public static string Encrypt(string dataToEncrypt)
        {
            AesManaged encryptor = new AesManaged();
            encryptor.Key = GetHashKey("Key");
            encryptor.IV = GetHashKey("IV");
            using (MemoryStream encryptionStream = new MemoryStream())
            {
                using (CryptoStream encrypt = new CryptoStream(encryptionStream, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    byte[] utfD1 = UTF8Encoding.UTF8.GetBytes(dataToEncrypt);
                    encrypt.Write(utfD1, 0, utfD1.Length);
                    encrypt.FlushFinalBlock();
                    encrypt.Close();
                    return Convert.ToBase64String(encryptionStream.ToArray());
                }
            }
        }
        // Comments out GetRunOption
        //public static string GetRunOption(string key)
        //{
        //    string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
        //    string sValue = ReadXMLConfiguration(ConfigPath, "Option", key);
        //    return sValue;
        //}

        // Comments out GetRunOption
        //public static string GetRunCategoryOption(string option, string key)
        //{
        //    string ConfigPath = Reports.DEPLOYDIR + "\\AutoConfig.xml";
        //    string sValue = ReadXMLConfiguration(ConfigPath, option, key);
        //    return sValue;

        //}

        private static string ReadXMLConfiguration(string ConfigPath, string option, string key)
        {
            string sValue = "";
            XmlDocument xDoc = new XmlDocument();
            if (File.Exists(ConfigPath))
            {
                xDoc.Load(ConfigPath);
                if (xDoc.DocumentElement.SelectSingleNode(Support.TESTENVIRONMENT + "/" + option + "/" + key) != null)
                    sValue = xDoc.DocumentElement.SelectSingleNode(Support.TESTENVIRONMENT + "/" + option + "/" + key).InnerText.ToString();
            }
            return sValue;
        }
        public static string Decrypt(string encryptedString)
        {
            try
            {
                AesManaged decryptor = new AesManaged();
                byte[] encryptedData = Convert.FromBase64String(encryptedString);
                decryptor.Key = GetHashKey("Key");
                decryptor.IV = GetHashKey("IV");
                using (MemoryStream decryptionStream = new MemoryStream())
                {
                    using (CryptoStream decrypt = new CryptoStream(decryptionStream, decryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        decrypt.Write(encryptedData, 0, encryptedData.Length);
                        decrypt.Flush();
                        decrypt.Close();
                        byte[] decryptedData = decryptionStream.ToArray();
                        return UTF8Encoding.UTF8.GetString(decryptedData, 0, decryptedData.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                Support.Fail("Encrypted password doesn't have the right length! " + ex.Message);
                Environment.Exit(1);
                return null;
            }

        }
    }
}
