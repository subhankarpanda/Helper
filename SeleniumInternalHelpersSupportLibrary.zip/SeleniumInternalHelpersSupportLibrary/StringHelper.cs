﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SeleniumInternalHelpersSupportLibrary
{
    /// <summary>
    ///   <description>
    ///     StringHelper can be used for cleaning up ASCII string characters.
    ///   </description>
    ///   <constructor>
    ///     new StringHelper(){ NBSP = true, CR = false }
    ///   </constructor>
    /// </summary>
    public class StringHelper
    {
        public bool Trim = true;
        public bool SingleSP = true;
        public bool LowerCase = false;
        public bool UpperCase = false;
        public bool SP = true;
        public bool NBSP = false;
        public bool CR = true;
        public bool LF = true;

        public string CleanUp(string paramString)
        {
            return _CleanUp(paramString);
        }

        private string _CleanUp(string objString)
        {
            if (Trim)
            {
                objString = objString.Trim();
            }
            if (SingleSP)
            {
                Regex regex = new Regex(@"(\s{2,})+", RegexOptions.None);
                objString = regex.Replace(objString.Trim(), @" ");
            }
            if (LowerCase)
            {
                objString = objString.ToLowerInvariant();
            }
            if (UpperCase)
            {
                objString = objString.ToUpperInvariant();
            }
            if (!SP)
            {
                objString = RemoveChar(objString, (char)32);
            }
            if (NBSP)
            {
                objString = objString.Replace((char)32, (char)160);
            }
            else
            {
                objString = objString.Replace((char)160, (char)32);
            }
            if (!CR)
            {
                objString = RemoveChar(objString, (char)13);
            }
            if (!CR)
            {
                objString = RemoveChar(objString, (char)10);
            }

            return objString;
        }

        private string RemoveChar(string objString, char c)
        {
            var len = objString.Length;
            string newString = objString;
            int x = 0;
            for(int i=0; i<len; i++)
            {
                if (objString[i] == c)
                {
                    newString = newString.Remove(i - x, 1);
                    x++;
                }
            }

            return objString;
        }
    }
}
